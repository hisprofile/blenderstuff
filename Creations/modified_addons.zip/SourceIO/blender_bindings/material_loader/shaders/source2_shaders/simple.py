from .vr_simple import VrSimple


class Simple(VrSimple):
    SHADER: str = 'simple.vfx'