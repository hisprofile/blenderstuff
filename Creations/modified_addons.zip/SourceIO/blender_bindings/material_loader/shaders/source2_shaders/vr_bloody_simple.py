from .vr_complex import VrComplex


class VRBloodySimple(VrComplex):
    SHADER: str = 'vr_bloody_simple.vfx'