from .vpk_file import open_vpk, VPKFile,InvalidMagic
