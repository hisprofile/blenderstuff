from ..v49 import MdlV49


class _AnimBlocks:
    def __init__(self):
        self.name = ''
        self.blocks = []


class MdlV52(MdlV49):
    pass